#1.1 implement a recrstive function to calculate the factorial of a given nmber

"""
1!=1x1
2!=2x1!------>2x1
3!=3x2x1!----->3x2x1
.
.
10!=10x9!----->10x9x8x7x6x5x4x3x2x1

formula-nx(n-1)!
"""


# Function to find factorial of given number
def factorial(n):
       
    if n == 0:
        return 1
      
    return n * factorial(n-1)
   
# Driver Code
num = 5;
print("Factorial of", num, "is",
factorial(num))


